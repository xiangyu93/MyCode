package com.nordicsemi.chy;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nordicsemi.nrfUARTv2.R;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by chengying on 2016/1/22.
 */
public class Detail extends Activity{
    private ImageView back_his;
    private Draw mdDraw;
    private Button btn_tiwen,btn_xinlv,btn_jibu;
    private TextView tx_jibu,tx_xinlv,tx_temture,tx_detail_title,tx_num;

    private int bushu = 1564;
    private int num = 1;
    private int xinlv = 98;
    private double temperature = 24;
    private  double[] xl = {7,6.5,7.5,7.7,8,8.5,7.6,7.5,7.5,7.5,7.5,7.5,
            7,6.5,7.5,7.7,8,8.5,8.7,8.3,7.6,7.5,7.5,7.5};

    private SDcard SDM = new SDcard();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.detail);

        Intent intent = getIntent();
        String data = intent.getStringExtra("data");

        JSONObject root = null;
        try {
            root = new JSONObject(data);
            num = root.getInt("n");
            temperature = root.getDouble("t");
            bushu = root.getInt("s");
            xinlv = root.getInt("h");
            int huxi = root.getInt("b");

            System.out.println(num + ">>>>>>>>>>");
            System.out.println(temperature + ">>>>>>>>>>");
            System.out.println(bushu + ">>>>>>>>>>");
            System.out.println(xinlv + ">>>>>>>>>>");
            System.out.println(huxi + ">>>>>>>>>>");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        mdDraw = (Draw) findViewById(R.id.draw_main_detail);
        mdDraw.getDatas(xl);
        mdDraw.setScal(24);
        mdDraw.invalidate();
        back_his = (ImageView) findViewById(R.id.back_tohis);
        btn_tiwen = (Button)findViewById(R.id.btn_tiwen_detail);
        btn_xinlv = (Button) findViewById(R.id.btn_xinlv_detail);
        btn_jibu = (Button) findViewById(R.id.btn_jibu_detail);
        tx_temture = (TextView) findViewById(R.id.temperature_detail);
        tx_xinlv = (TextView) findViewById(R.id.xinlv_detail);
        tx_jibu = (TextView) findViewById(R.id.jibu_detail);
        tx_num = (TextView) findViewById(R.id.tx_num_detail);
        tx_detail_title = (TextView) findViewById(R.id.tx_details_title);

        tx_num.setText("" + num);
        tx_temture.setText("" + temperature + "℃");
        tx_jibu.setText("" + bushu);
        tx_xinlv.setText("" + xinlv);
        tx_detail_title.setText("奶牛" + num + "号信息");

        mdDraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Detail.this)
                        .setTitle("呼吸：")
                        .setMessage("正常情况下，奶牛的呼吸频率为20次/min ，呼吸异常，" +
                                "肺炎或气管炎可引起牛呼吸急促、贫血、附红细胞体症、中毒、心脏畸形、" +
                                "日射病以及膨气症等状况。例如轻度热应激时，呼吸频率为50-60次/min ,中等程度热应激时，" +
                                "呼吸频率为80-120次/min，严重热应激情况下，呼吸频率可达120-160次/min，");
                setPositiveButton(builder).create().show();
            }
        });

        back_his.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        btn_tiwen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Detail.this)
                        .setTitle("体温：")
                        .setMessage("奶牛一般正常体温为37.5℃~39.5℃ ,孕牛犊牛0.5度上下浮动!体温异常。" +
                                "则体温奶牛可能发烧或有炎症,产后牛体温低可能是产褥热的表现 。例如体温到40度 ，有异食， 奶牛一般是有寄生虫 包括血液的寄生虫 以及肠道寄生虫 因为寄生虫在体内要分泌毒素" +
                                " 引起机体的免疫反抗 你可以驱驱肠道寄生虫 打打血液寄生虫。");
                setPositiveButton(builder).create().show();

            }
        });
        btn_xinlv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Detail.this)
                        .setTitle("心率：")
                        .setMessage("成年奶牛心率在70-90次/min,对不同妊娠阶心率不同，" +
                                "为评估交感和副交感神经提供参考，提高对奶牛妊娠期的奶牛繁殖效率或提高奶牛产奶性能上，" +
                                "同时，心率是判别急性心力衰竭的重要指标，" +
                                "心率增数100次/分以上，节律不齐，脉搏微弱，细而不整，体表颈静脉怒张。");
                setPositiveButton(builder).create().show();

            }
        });
        btn_jibu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Detail.this)
                        .setTitle("计步：")
                        .setMessage("发情奶牛一般都有明显的外部行为表现。" +
                                "比如说兴奋不安、哞叫、弓腰举尾，运步次数增加，频繁排尿；" +
                                "反刍、采食和泌乳减少，追爬其它牛或者是静立接受爬跨等。" +
                                "而且临床上上述的症状由弱到强，后又逐渐减弱乃至消失。" +
                                "而在发情初期表现出的兴奋不安等征候，但不接受其他母牛的爬跨。" +
                                "实践表明，当奶牛被其他母牛爬跨而站立不动，有90％的可能断定该头母牛正处于发情阶段，" +
                                "对发情奶牛与非发情奶牛每小时的被爬跨次数、爬跨次数、行走步次数进行对比和观察。" +
                                "在大多数牛群中发情期的母牛一天大约走7英里，是正常母牛走的2倍。" +
                                "用计步器试验(一般发情3英里举例的两倍以上)，现实成功率却达900／--100％之间");
                setPositiveButton(builder).create().show();

            }
        });
    }
    private AlertDialog.Builder setPositiveButton(AlertDialog.Builder builder){
        //调用setpositiveButton方法添加确定按钮
        return builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });

    }
}
