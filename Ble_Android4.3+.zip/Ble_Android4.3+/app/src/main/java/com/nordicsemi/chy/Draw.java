package com.nordicsemi.chy;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.util.AttributeSet;
import android.view.View;

class Draw extends View {


    private double[] xl = new double[24];
    //private double[] a = new double[24];
    private int XSCAL;

    public Draw(Context context) {
        super(context);
    }

    public Draw(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        // TODO Auto-generated method stub
        super.onDraw(canvas);

        //画坐标和gps的画笔
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3);
        paint.setTextSize(20);

        //描点和画心率的画笔
        Paint paintLine = new Paint();
        paintLine.setColor(Color.RED);
        paintLine.setStyle(Paint.Style.FILL);
        paintLine.setStrokeWidth(3);

        //呼吸画笔
        Paint paint2 = new Paint();
        paint2.setColor(Color.BLACK);
        paint2.setStyle(Paint.Style.FILL_AND_STROKE);
        paint2.setStrokeWidth(1);

        //温度画笔
        Paint paint3 = new Paint();
        paint3.setColor(Color.BLACK);
        paint3.setStyle(Paint.Style.FILL_AND_STROKE);
        paint3.setStrokeWidth(3);

        //注释画笔
        Paint paint1 = new Paint();
        paint1.setColor(Color.BLACK);
        paint1.setStrokeWidth(3);
        paint1.setTextSize(30);

        int ox = 40;
        int oy = 40;

        int M = getWidth() - ox;
        int N = getHeight() - oy;
//        int Xscal = M / 50;
        int Xscal = XSCAL;
        int Yscal = N / 60;
//        int X = Xscal * 50;
        int Y = Yscal * 60;
        int X1 = getWidth() - 10;
        int xscal = M / XSCAL;
        int X = Xscal * xscal;
        //Y
        canvas.drawLine(ox, Y, ox, ox, paint3);
        //X
        canvas.drawLine(X1, Y, ox, Y, paint3);
        // ��X���ͷ
        drawTriangle(canvas, new Point(X1, Y), new Point(X1 - 15, Y - 10),
                new Point(X1 - 15, Y + 10));
        canvas.drawText("X", X1 + 5, Y, paint3);
        // ��Y���ͷ
        drawTriangle(canvas, new Point(ox, oy), new Point(ox - 10, oy + 15),
                new Point(ox + 10, oy + 15));
        canvas.drawText("Y", ox + 12, ox + 15, paint2);
        for (int i = Xscal; i > 0; i--) {
            canvas.drawText(String.valueOf(Xscal - i), X + ox - i * xscal, Y + 20, paint2);
            canvas.drawText("|", X + ox - i * xscal, Y - 3, paint2);
            if (Xscal == 24) {
                i--;
            }

        }
        for (int i = 1; i <= 14; i++) {
            canvas.drawText(String.valueOf((i + 9) * 5), ox - 35, Y - i * 45, paint2);
            canvas.drawText("-", ox, Y - i * 45, paint3);
        }

//        for (int n = 0; n < gps.length; n++) {
//            canvas.drawCircle(X + ox - (Xscal - n) * xscal, Y - gps[n] * 45, 3, paintLine);
//        }

        for (int n = 0; n < xl.length; n++) {
            canvas.drawCircle(X + ox - (Xscal - n ) * xscal, (int) (Y - xl[n] * 45), 3, paintLine);
        }

        /*for (int n = 0; n < a.length; n++) {
            canvas.drawCircle(X + ox - (Xscal - n ) * xscal, (int)(Y - a[n] * 45), 3, paintLine);
        }
*/
        /*for (int n = 0; n < b.length; n++) {
            canvas.drawCircle(X + ox - (Xscal - n * 2) * xscal, Y - b[n] * 45, 3, paintLine);
        }*/
        //标注折线颜色与变量的关系
        //gps
//        canvas.drawLine(X - 100, 50, X - 50, 50, paint);
//        canvas.drawText("gps", X - 40, 50, paint1);
        //心率
        canvas.drawLine(X - 100, 90, X - 50, 90, paintLine);
        canvas.drawText("呼吸", X - 40, 90, paint2);
        //
       /* canvas.drawLine(X - 100, 130, X - 50, 130, paint2);
        canvas.drawText("呼吸", X - 40, 130, paint1);
        //*/
        /*canvas.drawLine(X - 100, 170, X - 50, 170, paint3);
        canvas.drawText("温度", X - 40, 170, paint1);*/

//        for (int m = 0; m < gps.length - 1; m++) {
//            canvas.drawLine(X + ox - (Xscal - m) * xscal, Y - gps[m] * 45, X + ox - (Xscal - m - 1) * xscal, Y - gps[m + 1] * 45, paint);
//        }

        for (int m = 0; m < xl.length - 1; m++) {
            canvas.drawLine(X + ox - (Xscal - m) * xscal, (int) (Y - xl[m] * 45), X + ox - (Xscal - m -1) * xscal, (int) (Y - xl[m + 1] * 45), paintLine);
            System.out.println(xscal);
        }

       /* for (int m = 0; m < a.length - 1; m++) {
            canvas.drawLine(X + ox - (Xscal - m) * xscal, (int)(Y - a[m] * 45), X + ox - (Xscal - m -1) * xscal, (int)(Y - a[m + 1] * 45), paint2);
        }*/

        /*for (int m = 0; m < b.length - 1; m++) {
            canvas.drawLine(X + ox - (Xscal - m * 2) * xscal, Y - b[m] * 45, X + ox - (Xscal - m * 2 - 2) * xscal, Y - b[m + 1] * 45, paint3);
        }
*/

    }

    private void drawTriangle(Canvas canvas, Point p1, Point p2, Point p3) {
        Path path = new Path();
        path.moveTo(p1.x, p1.y);
        path.lineTo(p2.x, p2.y);
        path.lineTo(p3.x, p3.y);
        path.close();
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        // ������������
        canvas.drawPath(path, paint);
    }

    private int stringToint(String s) {
        int y;
        y = Integer.parseInt(s);
        return y;
    }

    public void getDatas(double[] xl) {
        this.xl = xl;
        //this.a = a;
    }

    public void setScal(int XSCAL) {
        this.XSCAL = XSCAL;
    }
}
