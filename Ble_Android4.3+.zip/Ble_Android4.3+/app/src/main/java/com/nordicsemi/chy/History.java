package com.nordicsemi.chy;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.nordicsemi.nrfUARTv2.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class History extends Activity {

    private ListView list = null;
    private ImageView back;

    //	protected Draw historyDraw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.history);


        back = (ImageView) findViewById(R.id.back_home);
        back.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();
            }
        });


        List<Map<String, String>> listItems = new ArrayList<Map<String, String>>();
        for (int i = 0; i < 7; i++) {
            Map<String, String> listItem = new HashMap<String, String>();
            listItem.put("time", getBeforeday(i));
            listItem.put("cownum","001");
            listItems.add(listItem);
        }

        SimpleAdapter simpleAdapter = new SimpleAdapter(this, listItems,
                R.layout.history_item01,
                new String[]{"time","cownum"},
                new int[]{R.id.items,R.id.tx_cownum});

        list = (ListView) findViewById(R.id.mylist);

        list.setAdapter(simpleAdapter);

        list.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                System.out.println("position = " + position + ">>> " + "id = " + id);

                String data = null;
                String hisDate = null;
                SDcard hisSD = new SDcard();

                //判断文件是否存在，若存在则读取数据，若不存在则取消操作或联网读取
                
                data = hisSD.read(getBeforeday(position));
                if(data.equals("")){
                    Toast.makeText(getApplicationContext(), "历史数据不存在", Toast.LENGTH_LONG);
                    finish();
                }else{
                    hisDate = getBeforeday(position);

                    Intent toDetail = new Intent(History.this, Detail.class);
                    toDetail.putExtra("data", data);
                    toDetail.putExtra("hisDate", hisDate);
                    startActivity(toDetail);
                }

            }
        });
    }

    private String getTime() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss", Locale.getDefault());
        Date data = new Date();
        String str = format.format(data);
        return str;
    }

    private String getTime01() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 ");
        Date data = new Date();

        String str = format.format(data);
        return str;
    }

    private String getBeforeday(int a) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日");
        Date dNow = new Date();
        Date dBefore = new Date();

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dNow);
        calendar.add(Calendar.DAY_OF_MONTH, -a);
        dBefore = calendar.getTime();
        String beforeDay = format.format(dBefore);
        String nowDay = format.format(dNow);

        if (a == 0) {
            return nowDay;
        } else {
            return beforeDay;
        }

    }

}
