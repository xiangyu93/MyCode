package com.nordicsemi.chy;

import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class SDcard {

	private String PATH = null;

	public void write(String content, String fileName){
		if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
			//获取SD卡目录
			File sdCardDir = new File("/mnt/sdcard/");

			try {
				//File targetFile = new File(sdCardDir
				//.getCanonicalPath() + fileName);
				//				//以指定文件创建RandomAccessFile
				//				RandomAccessFile raf = new RandomAccessFile(targetFile, "rw");
				//				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>1111");
				//				//将文件记录指针移到最后
				//				raf.seek(targetFile.length());
				//				//输出文件内容
				//				raf.write(content.getBytes());
				//				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>1111");
				//				//关闭RandomAccessFile
				//				raf.close();
				//				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>1111");
				PATH = sdCardDir.getPath()+"/奶牛监护";
				File path01 = new File(PATH);


				if (!path01.exists()) {
					//若不存在，创建目录，可以在应用启动的时候创建
					path01.mkdirs();
				}

				File targetFile = new File(path01 + "/" + fileName + ".txt");
				if (!targetFile.exists()){
					//若文件不存在则存储
					OutputStream out=new FileOutputStream(targetFile);
					out.write(content.getBytes());
					out.close();
				}




			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public String read(String fileName){
		if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
			File sdCardDir = new File("/mnt/sdcard/");
			PATH = sdCardDir.getPath()+"/奶牛监护";
			File path01 = new File(PATH);
			File targetFile = new File(path01 +"/" + fileName + ".txt");

			if (targetFile.exists()){
				//获取指定文件对应的输入流
				try {
					FileInputStream fis = new FileInputStream(targetFile);
					//将指定输入流包装成BufferedReader
					BufferedReader br = new BufferedReader(new InputStreamReader(fis));
					StringBuilder sb = new StringBuilder("");
					String line = null;
					//循环读取文件
					while((line = br.readLine()) != null){
						sb.append(line);
					}
					//关闭资源
					br.close();
					return sb.toString();

				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}



		}
		return null;
	}

	public void delete(String fileName){
		File sdCardDir = new File("/mnt/sdcard/");
		PATH = sdCardDir.getPath()+"/测试用文件夹";
		File file = new File(PATH+ "/" + fileName + ".txt");
		file.delete();
	}

}
