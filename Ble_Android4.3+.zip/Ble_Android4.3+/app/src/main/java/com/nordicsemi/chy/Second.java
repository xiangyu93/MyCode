package com.nordicsemi.chy;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Message;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.nordicsemi.nrfUARTv2.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Handler;

/**
 * Created by chengying on 2015/7/17.
 */
public class Second extends Activity {

    protected Draw mDraw;
    protected ImageView back_login;
    protected Button tohistory,btn_tiwen,btn_xinlv,btn_jibu;
    protected Button menu;
    protected TextView jibu;
    protected TextView tx_xinlv,tx_num;
    protected TextView weidu;
    protected TextView temture;

    private int bushu = 1564;
    protected double temperature = 24;
    protected  int num = 1;
    protected  double xinlv = 98;
    private String text;
    private String value = null;
    private int i = 0,j = 0,k = 0;

    private android.os.Handler mhandler;

    PopupWindow myMenu;
    private SDcard SDM = new SDcard();
    private Map<String, String> params = new HashMap<String, String>();
    private String valu;
    private  double[] xl = {7,6.5,7.5,7.7,8,8.5,7.6,7.5,7.5,7.5,7.5,7.5,
           7,6.5,7.5,7.7,8,8.5,8.7,8.3,7.6,7.5,7.5,7.5};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.draw_test);

        LocalBroadcastManager.getInstance(this).
                registerReceiver(UARTStatusChangeReceiver, makeGattUpdateIntentFilter());





        mhandler = new android.os.Handler(){
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if(msg.what == 0x123){
                    JSONObject root = null;

                    if(k == 0){value = text;k++;}
                    else if(k == 1){value =value + text;k++;}
                    else{value =value + text;k=0;
                        System.out.println(value);
                        //将信息储存到SD卡中
                        SDM.write(value ,getTime());
                        try {
                            root = new JSONObject(value);
                            num = root.getInt("n");
                            temperature = root.getDouble("t");
                            bushu = root.getInt("s");
                            xinlv = root.getInt("h");
                            int huxi = root.getInt("b");

                            System.out.println(num + ">>>>>>>>>>");
                            System.out.println(temperature + ">>>>>>>>>>");
                            System.out.println(bushu + ">>>>>>>>>>");
                            System.out.println(xinlv + ">>>>>>>>>>");
                            System.out.println(huxi + ">>>>>>>>>>");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

                }

            }
        };

        mDraw = (Draw) findViewById(R.id.draw_main);
        mDraw.getDatas(xl);
        mDraw.setScal(24);
        mDraw.invalidate();
        back_login = (ImageView) findViewById(R.id.back_login);
        tohistory = (Button) findViewById(R.id.btn_tohistory);
        btn_tiwen = (Button)findViewById(R.id.btn_tiwen);
        btn_xinlv = (Button) findViewById(R.id.btn_xinlv);
        btn_jibu = (Button) findViewById(R.id.btn_jibu);
        //menu = (Button) findViewById(R.id.mymenu);
        jibu = (TextView)findViewById(R.id.jibu);
        tx_xinlv = (TextView) findViewById(R.id.xinlv);
        tx_num = (TextView) findViewById(R.id.tx_num);
        temture = (TextView) findViewById(R.id.temperature);

        //设置控件内容
        tx_num.setText(""+num);
        temture.setText("" + temperature + "℃");
        tx_xinlv.setText("" + xinlv);
        jibu.setText("" + bushu);



        mDraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Second.this)
                        .setTitle("呼吸：")
                        .setMessage("正常情况下，奶牛的呼吸频率为20次/min ，呼吸异常，" +
                                "肺炎或气管炎可引起牛呼吸急促、贫血、附红细胞体症、中毒、心脏畸形、" +
                                "日射病以及膨气症等状况。例如轻度热应激时，呼吸频率为50-60次/min ,中等程度热应激时，" +
                                "呼吸频率为80-120次/min，严重热应激情况下，呼吸频率可达120-160次/min，");
                setPositiveButton(builder).create().show();
            }
        });

        back_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btn_tiwen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Second.this)
                        .setTitle("体温：")
                        .setMessage("奶牛一般正常体温为37.5℃~39.5℃ ,孕牛犊牛0.5度上下浮动!体温异常。" +
                                "则体温奶牛可能发烧或有炎症,产后牛体温低可能是产褥热的表现 。例如体温到40度 ，有异食， 奶牛一般是有寄生虫 包括血液的寄生虫 以及肠道寄生虫 因为寄生虫在体内要分泌毒素" +
                                " 引起机体的免疫反抗 你可以驱驱肠道寄生虫 打打血液寄生虫。");
                setPositiveButton(builder).create().show();

            }
        });
        btn_xinlv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Second.this)
                        .setTitle("心率：")
                        .setMessage("成年奶牛心率在70-90次/min,对不同妊娠阶心率不同，" +
                                "为评估交感和副交感神经提供参考，提高对奶牛妊娠期的奶牛繁殖效率或提高奶牛产奶性能上，" +
                                "同时，心率是判别急性心力衰竭的重要指标，" +
                                "心率增数100次/分以上，节律不齐，脉搏微弱，细而不整，体表颈静脉怒张。");
                setPositiveButton(builder).create().show();
            }
        });
        btn_jibu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(Second.this)
                        .setTitle("计步：")
                        .setMessage("发情奶牛一般都有明显的外部行为表现。" +
                                "比如说兴奋不安、哞叫、弓腰举尾，运步次数增加，频繁排尿；" +
                                "反刍、采食和泌乳减少，追爬其它牛或者是静立接受爬跨等。" +
                                "而且临床上上述的症状由弱到强，后又逐渐减弱乃至消失。" +
                                "而在发情初期表现出的兴奋不安等征候，但不接受其他母牛的爬跨。" +
                                "实践表明，当奶牛被其他母牛爬跨而站立不动，有90％的可能断定该头母牛正处于发情阶段，" +
                                "对发情奶牛与非发情奶牛每小时的被爬跨次数、爬跨次数、行走步次数进行对比和观察。" +
                                "在大多数牛群中发情期的母牛一天大约走7英里，是正常母牛走的2倍。" +
                                "用计步器试验(一般发情3英里举例的两倍以上)，现实成功率却达900／--100％之间");
                setPositiveButton(builder).create().show();
            }
        });

        tohistory.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent toHistory = new Intent(Second.this, History.class);
                startActivity(toHistory);
            }
        });
//        menu.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (myMenu != null && myMenu.isShowing()) {
//                    myMenu.dismiss();
//                    return;
//                } else {
//                    setMenu();
//                    myMenu.showAsDropDown(menu, 0, 5);
//                }
//            }
//        });

    }


    private AlertDialog.Builder setPositiveButton(AlertDialog.Builder builder){
        //调用setpositiveButton方法添加确定按钮
        return builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });

    }

    private final BroadcastReceiver UARTStatusChangeReceiver = new BroadcastReceiver(){
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action.equals(UartService.ACTION_DATA_AVAILABLE)) {

                final byte[] txValue = intent.getByteArrayExtra(UartService.EXTRA_DATA);
                runOnUiThread(new Runnable() {
                    public void run() {
                        try {
                            text = new String(txValue, "UTF-8");
                            System.out.println(text);
//Thread thread = new Thread(){
//    @Override
//    public void run() {
//        super.run();
//        try {
//            sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//    }
//};
//  thread.start();
                            mhandler.sendEmptyMessage(0x123);



                        } catch (Exception e) {
                        }
                    }
                });
            }
        }
    };

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(UartService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(UartService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(UartService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(UartService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction(UartService.DEVICE_DOES_NOT_SUPPORT_UART);
        return intentFilter;
    }

//    private void setMenu() {
//        final View myMenuView = getLayoutInflater().inflate(R.layout.choose, null, false);
//        myMenu = new PopupWindow(myMenuView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        myMenuView.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                if (myMenu != null && myMenu.isShowing()) {
//                    myMenu.dismiss();
//                    myMenu = null;
//                }
//                return false;
//            }
//        });
//        Button yearBtn = (Button) myMenuView.findViewById(R.id.year_history);
//        Button monthBtn = (Button) myMenuView.findViewById(R.id.month_history);
//        Button gpsBtn = (Button) myMenuView.findViewById(R.id.gps);
//        yearBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent year_intent = new Intent();
//                year_intent.putExtra("scal", 12);
//                year_intent.setClass(Second.this, DetailS.class);
//                startActivity(year_intent);
//                myMenu.dismiss();
//            }
//        });
//        monthBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent mionth_intent = new Intent();
//                mionth_intent.putExtra("scal", 12);
//                mionth_intent.setClass(Second.this, DetailS.class);
//                startActivity(mionth_intent);
//                myMenu.dismiss();
//            }
//        });
//        gpsBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent gps_intent = new Intent();
//                gps_intent.setClass(Second.this, GPSActivity.class);
//                startActivity(gps_intent);
//                myMenu.dismiss();
//            }
//        });
//    }


    private String getTime() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日");
        Date data = new Date();
        String str = format.format(data);
        return str;
    }
}
